Docker作业 v4 证据说明

v4是报告与交付资料修订版本，本轮没有重新执行Docker实验，也没有重新采集UI。
windows-original/ 保留原Windows实验凭证，来自v3证据包，文件名和字节均未改。
linux-v3/ 保留2026-10-21的真实Linux补充实验，文件名和字节均未改。
该轮使用平台已部署Docker，引擎28.4.0、Compose2.40.3，创建独立网络与数据卷，
构建并运行配套JAR镜像、发布到本机15085端口Registry，删除v3应用容器和本地镜像后拉取，
使用同一数据卷创建新容器并校验完整榜单。

原Windows镜像版本1.0.0、应用端口18085、仓库5000；Linux补充版本1.0.1-v3、应用18086、仓库15085。
两者分别记录摘要及容器标识。v4没有新建镜像版本，也未将Linux截图用作原Windows安装凭证。
Linux实验沿用平台已提供的Docker引擎，没有声称重新安装Docker；仓库地址仅在各自实验机器可访问。

v4 Word内共21张图：正文图1至图11对应windows-original/，附录图A1a、A1b和A2至A9对应linux-v3/。
图A1a对应01-resource-creation.png，展示实际资源创建；图A1b对应01-config-review.png，展示随后配置验证。
01-linux-config.txt保存首次创建资源命令。A2至A9沿用原图号及来源，不因A1拆分而重新编号。
02-image-build.txt保存首次构建，02-build-review.png保存实际再次构建及交付JAR校验。
原始终端transcript含ANSI控制码，未将日志绘制为截图。PNG为真实终端窗口或浏览器像素采集。
results.json、before/after-leaderboard.json与saved-score.json记录该轮实际结果，未虚构成绩。
日志和脚本中的路径反映当时执行工作区，迁移复现实验时需调整路径。

源码包的唯一JAR沿用v3原始字节，其SHA-256与linux-v3/results.json中的交付JAR、容器JAR一致。
v4桌面和手机预览沿用v3交付PNG原始字节，UI未修改，不表示v4重新采集了页面。
本证据包相对v3仅更新根README.txt与manifest-sha256.json。
manifest-sha256.json列出本包除摘要清单自身以外每个条目的字节数和SHA256。
