Docker作业 v5 证据说明（2026-10-22）

v5修复报告结构并补入本机真实复测记录。原Windows和Linux两轮实验不改写：
windows-original/ 为2026-10-21原Windows实验：镜像1.0.0，应用18085，Registry5000。
linux-v3/ 为2026-10-21 Linux补充实验：镜像1.0.1-v3，应用18086，Registry15085。
这两个目录的全部文件均与v4证据ZIP逐字节一致；v4顶层README和摘要清单的原件
另外存于history-v4/，不覆盖历史说明，且不把原说明中的v4结论当作v5现状。

windows-localtest-20261022/ 为2026-10-22用户恢复Docker Desktop后的真实本机复测。
Docker Client/Server29.8.2；源码镜像标签localtest-20261022；应用18087、Registry15086。
原始源码构建日志显示BuildKit缓存复用；不声称在容器内重新执行Maven测试。
本机源码干净构建成功、后端3项测试通过；实际交付JAR的浏览器3项测试通过，
8个UI自动审核场景通过；独立Docker容器上的浏览器3项测试通过。
实际push、移除本轮应用容器和两个镜像标签、确认标签不存在、pull、创建新容器，
完整榜单一致；推送/拉取目标仓库digest一致。详见results.json及对应原始命令日志。
本轮使用独立数据卷，没有把测试成绩混入原作业数据库；新容器页面无pageerror。

交付JAR继续沿用v4原字节，SHA256为
2e97ff46f2acfc1bfe0411a22f3f61a3ef4b8958e4ba5fff609d0350853852a0。
源码镜像内JAR的整包SHA256为
6126a1faf7e80ec948c5be2b50d834c7f3a4ef9f65089fcd49431f532a1b1389。
两个整包摘要不同，但BOOT-INF下61项的应用、资源和依赖内容完全相同，
参见source-image-vs-delivery.json；未把ZIP元数据差异称为应用内容变更。

本轮browser-before/的desktop-ready.png与mobile-ready.png就是v5独立预览的原件，
均为2026-10-22新建独立测试容器的真实页面像素，采集于发布和拉取重建之前。
after-recreate-ui.png为同日拉取后新容器的真实榜单页面截图。PNG未作编辑或合成。
历史终端截图保留原图，本轮命令过程提供日志，不把日志绘制成截图。

最初脚本比较完整RepoDigests数组，因推送前另有源仓库别名而触发断言；
改为比较目标Registry仓库的digest后，使用同一轮原始结果重新核验通过。
保留results-before-repository-normalization.json与results.json及recheck日志，
不隐瞒这次验证脚本修正，也未因此重做或改写实际Docker操作结果。

本包不重复加入JAR、运行数据库或与作业无关的完整容器清单；完整过程保存在
项目docs/local-test-20261022/。本轮所选原始日志、JSON、PNG、脚本字节不改。
路径和浏览器可执行文件反映采集机器；迁移复现时需调整本机路径并检查端口。
所有Registry均只对各自本机开放，不是其他机器可以直接访问的公开镜像地址。
未取得的Windows安装/首次配置全过程历史截图没有补造，需按教师实际口径复核。

manifest-sha256.json覆盖本包除该清单自身之外全部条目的大小和SHA256。
