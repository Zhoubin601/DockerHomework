2026-10-21 Docker experiment 6085
11 original screenshots embedded in the Word report, plus actual machine-readable experiment results.
Registry scope: localhost:5000. Application: localhost:18085.
