Docker作业 v3 证据说明

windows-original/ 原Windows实验凭证，来自v2证据包，字节未改。
linux-v3/ 2026-10-21真实Linux补充实验，使用平台已部署Docker，引擎28.4.0、Compose2.40.3。
本轮创建独立网络与数据卷，构建并运行配套JAR镜像、发布到本机15085端口Registry，
删除v3应用容器和本地镜像后拉取，使用同一数据卷创建新容器并校验完整榜单。

原Windows镜像版本1.0.0、应用端口18085、仓库5000；Linux补充版本1.0.1-v3、应用18086、仓库15085。
两者分别记录摘要及容器标识。本轮Linux截图不表示原Windows安装或首次配置过程。
本轮沿用已提供的Docker引擎，没有声称重新安装Docker。仓库地址仅在各自实验机器可访问。

Word正文图1至图11对应windows-original/，附录图A1至图A9对应linux-v3/。
01-linux-config.txt保存首次创建资源命令，01-config-review.png为随后实际复核的终端截图。
02-image-build.txt保存首次构建，02-build-review.png保存可复现的再次构建及交付JAR校验。
原始终端transcript含ANSI控制码，未将日志绘制为截图。PNG为真实终端窗口或浏览器像素采集。
results.json、before/after-leaderboard.json与saved-score.json记录实际结果，未虚构成绩。
日志和脚本中的路径反映实际执行工作区，迁移复现实验时需调整路径。

manifest-sha256.json列出本包除摘要清单自身以外每个条目的字节数和SHA256。
